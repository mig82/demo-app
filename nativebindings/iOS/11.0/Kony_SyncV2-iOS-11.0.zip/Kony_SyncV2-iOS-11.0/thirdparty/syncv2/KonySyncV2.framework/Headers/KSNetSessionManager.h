//
//  KSNetworkSessionManager.h
//  SyncNetworkUtil
//
//  Created by Girish Lingarajappa Haniyamballi on 25/11/16.
//  Copyright © 2016 Girish Lingarajappa Haniyamballi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KSHTTPRequest.h"
#import "KSNetTaskInfo.h"
#import "KSNetConstants.h"

@interface KSNetSessionManager : NSObject

/**
 Session Level control to allow selfsigned/ssl pinning certificates
 */
@property(nonatomic, assign) KSNetServiceAllowableCertificates allowableCertificates;

/**
 Creates or returns existing instance of KSNetSessionManager.

 @return singelton instance of KSNetSessionManager
 */
+ (id)sharedManager;

/**
 Maps the said Taskinfo with the SessionTask.

 @param taskInfo taskInfo to be mapped. (TaskInfo contains completion handler ,response data and other info related to task.
 @param sessiontask session task with which the task info is mapped
 */
- (void)setTaskInfo:(KSNetTaskInfo *)taskInfo
     forSessionTask:(NSURLSessionTask *)sessiontask;

/**
 Removes the task form taskInfoMap
 On completion, the sessiontask being managed should be removed using this method
 @param sessiontask to be removed
 */

- (void)removeSessionTask:(NSURLSessionTask *)sessiontask;


/**
 taskInfoForSessionTask
 @param sessiontask essiontask for which taskInfo is needed.
 @return Returns taskinfo for given task
 */
- (KSNetTaskInfo *)taskInfoForSessionTask:(NSURLSessionTask *)sessiontask;


/**
 completionHandlerForSessionTask
 Returns completion handler for a given task.
 @param sessiontask for which completionhandler is needed.
 @return Returns completion handler associated with the task.
 */
- (KSNetworkCompletionHandler)completionHandlerForSessionTask:(NSURLSessionTask *)sessiontask;

/**
 sessionTaskForURLRequest
 Creates a session task based on request object
 Task needs to be created depending on the HTTP method and background support settings.
 In case of no background support , datatask is created.
 For background support, upload/download task with background session configuration is used.
 @param request contains the request properties.
 @param completionHandler is the handler to be invoked on request completion.
 @param options is used to read configuration set by user .Currently reads setting for  backgdound transfers (enabled/disabled).
 @return NEwly created task for the request type.
 */
- (NSURLSessionTask *)sessionTaskForURLRequest:(KSHTTPRequest *)request
                             completionHandler:(id)completionHandler
                                       options:(NSDictionary *)options
                                         error:(NSError *)error;

@end
