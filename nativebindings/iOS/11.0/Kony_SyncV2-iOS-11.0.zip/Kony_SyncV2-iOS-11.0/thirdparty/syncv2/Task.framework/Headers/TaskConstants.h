//
//  TaskConstants.h
//  TaskFrameworkLibrary
//
//  Created by MADP on 07/09/16.
//  Copyright © 2016 MADP. All rights reserved.
//

#import <Foundation/Foundation.h>

//TODO: Discuss the error domains and codes...

//Context related
FOUNDATION_EXPORT NSString *const kTaskErrors;
FOUNDATION_EXPORT NSString *const kTaskInputContext;
FOUNDATION_EXPORT NSString *const kTaskOutputContext;
FOUNDATION_EXPORT NSString *const kTaskErrorContext;

//Error Domains
FOUNDATION_EXPORT NSString *const kTaskNestedErrorDomain;
FOUNDATION_EXPORT NSString *const kTaskSubtaskErrorDomain;
FOUNDATION_EXPORT NSString *const kTaskInvalidInputErrorDomain;
FOUNDATION_EXPORT NSString *const kTaskSubtaskTaskAlreadyStartedErrorDomain;
FOUNDATION_EXPORT NSString *const kTaskSubtaskCyclicParentChildErrorDomain;
FOUNDATION_EXPORT NSString *const kTaskSubtaskCyclicDependencyErrorDomain;
FOUNDATION_EXPORT NSString *const kTaskSubtaskMultipleParentsErrorDomain;
FOUNDATION_EXPORT NSString *const kTaskSubtaskInvalidDependencyErrorDomain;
FOUNDATION_EXPORT NSString *const kTaskSubtaskMaxTasksReachedErrorDomain;

/**
 *  All the Task Framework error codes are listed out below.
 *
 *  Task Errors - (2100 - 2120)
 *
 *  Reserved range for Future Use - (2121 - 2140)
 */
//Error Codes
static const NSInteger kTaskInvalidInputErrorCode = 2100;
static const NSInteger kTaskNestedErrorCode = 2101;
static const NSInteger kTaskSubtaskTaskAlreadyStartedErrorCode = 2102;
static const NSInteger kTaskSubtaskMaxTasksReachedErrorCode = 2103;
static const NSInteger kTaskSubtaskCyclicDependencyErrorCode = 2104;
static const NSInteger kTaskSubtaskCyclicParentChildErrorCode = 2105;
static const NSInteger kTaskSubtaskMultipleParentsErrorCode = 2106;
static const NSInteger kTaskSubtaskInvalidDependencyErrorCode = 2107;


@interface TaskConstants : NSObject

@end
